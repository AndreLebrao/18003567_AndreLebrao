package br.maua;

import br.maua.game.PicturePoker;

public class Main {
    public static void main(String[] args) throws Exception {
        PicturePoker.run();
    }
}
