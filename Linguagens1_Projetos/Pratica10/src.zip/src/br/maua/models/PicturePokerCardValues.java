package br.maua.models;

public enum PicturePokerCardValues {
    CLOUD, SUPER_MUSHROOM, FIRE_FLOWER, LUIGI, MARIO, SUPER_STAR;
}